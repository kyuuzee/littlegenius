<!DOCTYPE html>
<html>
    <head> 
        <title>Login</title>
    </head>
    
    <body>
        <?php

        if (!($connection = mysqli_connect("localhost","root","")))
            die ("Could not connect to the database </body></html>");

        if (!mysqli_select_db($connection,"littlegenius"))
            die ("Could not open littlegenius database </body></html>");

        $email = mysqli_real_escape_string($connection, $_POST["email"]);
        
        $pwd = mysqli_real_escape_string($connection, $_POST["pwd"]);
        
        $query = "SELECT * FROM users WHERE email = '$email'";
        
        $result = mysqli_query($connection,$query);

        if (!($result)) {
            echo "<p> could not execute query! </p>";
            die (mysqli_error($connection)."</body></html>");
        }
        
       if(mysqli_num_rows($result)>0){
            
            while($row = mysqli_fetch_array($result)) {
                
                $hash = md5($pwd, PASSWORD_DEFAULT);
                
                if ($hash == $row[2]) {
                    mysqli_close($connection);
                    setcookie("username", $row[1],time()+24*60*60);
                    setcookie("email", $row[0]);
                    header ('location: account.html');
                }
                else {
                    mysqli_close($connection);
                    echo "<script>
                    alert('Wrong email or password. Please try again.');
                    window.location.href='homepage.html';
                    </script>";
                }
            }
        }

?>
        </body>
</html>
