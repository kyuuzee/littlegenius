<!DOCTYPE html>

<html>
    <body>
        <?php
            setcookie('username',"", time()-3600);
            header ('location: homepage.html');
        ?>
    </body>
</html>