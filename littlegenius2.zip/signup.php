<!DOCTYPE html>

<html>
	<head>
        <title>Login page</title>
	</head>
	<body>
        <?php
            if (!($connection = mysqli_connect("localhost","root","")))
                die ("Could not connect to the database </body></html>");
            
            if (!mysqli_select_db($connection,"littlegenius"))
                die ("Could not open little genius database </body></html>");
            
            
            extract($_POST);
            $email = mysqli_real_escape_string($connection, $_POST["email"]);
            $pwd = mysqli_real_escape_string($connection, $_POST["pwd"]);
            $username = mysqli_real_escape_string($connection, $_POST["username"]);
        
            $hash = md5($pwd, PASSWORD_DEFAULT);
            
            $query = "INSERT INTO users (email,username,pwd) VALUES ('$email','$username','$hash')";
        
            if (!($result = mysqli_query($connection,$query))) {
                echo "<p> could not execute query! </p>";
                die (mysqli_error($connection)."</body></html>");
            }
            
            mysqli_close($connection);
            setcookie("username",$username);
            setcookie("email",$email);
            header("Location: account.html");
        ?>
	</body>
</html>