<!DOCTYPE html>

<html>
	<head>
        <title>Progress for Multiplication</title>
	</head>
	<body>
        <?php
            if (!($connection = mysqli_connect("localhost","root","")))
                die ("Could not connect to the database </body></html>");
            
            if (!mysqli_select_db($connection,"littlegenius"))
                die ("Could not open little genius database </body></html>");
        
            $email = $_COOKIE["email"];
            
            $query = "UPDATE users SET multiplication = 1 WHERE email = '$email'";
        
            if (!($result = mysqli_query($connection,$query))) {
                echo "<p> could not execute query! </p>";
                die (mysqli_error($connection)."</body></html>");
            }
            
            mysqli_close($connection);
            setcookie("multiplication",1);
            header("Location: account.html");
        ?>
	</body>
</html>